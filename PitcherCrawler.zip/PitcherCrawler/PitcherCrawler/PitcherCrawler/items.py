# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class PitchercrawlerItem(scrapy.Item):
    # define the fields for your item here like:
    playerName = scrapy.Field()
    eraNumber = scrapy.Field()
    whipNumber = scrapy.Field()
    wlNumber = scrapy.Field()
    gamesNumber = scrapy.Field()
    cgNumber= scrapy.Field()
    shoNumber = scrapy.Field()
    svNumber = scrapy.Field()
    ipNumber = scrapy.Field()
    hNumber = scrapy.Field()
    rNumber = scrapy.Field()
    erNumber= scrapy.Field()
    bbNumber = scrapy.Field()
    soNumber = scrapy.Field()
    doublesNumber = scrapy.Field()
    triplesNumber = scrapy.Field()
    hrNumber = scrapy.Field()
    abNumber = scrapy.Field()
    bavgNumber = scrapy.Field()
    wpNumber = scrapy.Field()
    hbpNumber = scrapy.Field()
    bkNumber = scrapy.Field()
    sfaNumber = scrapy.Field()
    shaNumber = scrapy.Field()
    fipNumber= scrapy.Field()
    kPercentageNumber= scrapy.Field()
    bbPercentageNumber= scrapy.Field()
    kPer9Number= scrapy.Field()
    bbPer9Number= scrapy.Field()
    hrPer9Number= scrapy.Field()
    babipNumber= scrapy.Field()
