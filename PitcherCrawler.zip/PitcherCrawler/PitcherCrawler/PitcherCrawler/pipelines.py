# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
import mysql.connector

class PitchercrawlerPipeline:
    def __init__(self):
        self.create_connection()
        self.create_table()

    def create_connection(self):
        self.conn = mysql.connector.connect(host='167.99.39.236', user='uncacsci_tlittle2', password='ghyvmlanqrzi', database='uncacsci_tlittle2')
        self.curr = self.conn.cursor()

    def create_table(self):
        print("inside create table...")
        self.curr.execute("""DELETE FROM pitchers_spring""")
        # print("After drop....")
        '''
        self.curr.execute("""CREATE TABLE pitchers_spring(
                               playerName varchar(100),
                               ERA FLOAT,
                               WHIP FLOAT,
                               WL varchar(7),
                               APP_GS varchar(7),
                               CG INT(11),
                               SHO varchar(7),
                               SV INT(11),
                               IP FLOAT,
                               H INT(11),
                               R INT(11),
                               ER INT(11),
                               BB INT(11),
                               SO INT(11),
                               2B INT(11),
                               3B INT(11),
                               HR INT(11),
                               AB FLOAT,
                               B_AVG FLOAT,
                               WP INT(11),
                               HBP INT(11),
                               BK INT(11),
                               SFA INT(11),
                               SHA INT(11),
                               FIP FLOAT,
                               kPercentage FLOAT,
                               bbPercentage FLOAT,
                               Kper9 FLOAT,
                               BBper9 FLOAT,
                               HRper9 FLOAT,
                               BABIP FLOAT    
                               )""")
        '''
    def storeItem(self, item):
        self.curr.execute("""INSERT INTO pitchers_spring(playerName, ERA, WHIP, WL, APP_GS, CG, SHO, SV, IP, H, R, ER, BB, SO, 2B, 3B, HR, AB, B_AVG, WP, HBP, BK, SFA, SHA, 
        FIP, kPercentage, bbPercentage, Kper9, BBper9, HRper9, BABIP)
        VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s) """,(
                              item['playerName'],
                              str(item['eraNumber']),
                              str(item['whipNumber']),
                              item['wlNumber'],
                              item['gamesNumber'],
                              item['cgNumber'],
                              item['shoNumber'],
                              item['svNumber'],
                              str(item['ipNumber']),
                              item['hNumber'],
                              item['rNumber'],
                              item['erNumber'],
                              item['bbNumber'],
                              item['soNumber'],
                              item['doublesNumber'],
                              item['triplesNumber'],
                              item['hrNumber'],
                              item['abNumber'],
                              str(item['bavgNumber']),
                              item['wpNumber'],
                              item['hbpNumber'],
                              item['bkNumber'],
                              item['sfaNumber'],
                              item['shaNumber'],
                              item['fipNumber'],
                              item['kPercentageNumber'],
                              item['bbPercentageNumber'],
                              item['kPer9Number'],
                              item['bbPer9Number'],
                              item['hrPer9Number'],
                              item['babipNumber']



                          ))
        self.conn.commit()

    def process_item(self, item, spider):
        self.storeItem(item)
        return item
