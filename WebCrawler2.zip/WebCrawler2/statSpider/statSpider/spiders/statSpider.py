from lib2to3.pgen2 import driver

import scrapy
from ..items import StatspiderItem
import mysql.connector

playerInfo = []
playerAttributes = {
    "PlayerName": 0

}


def stringCheck(element, start):
    # print("inside string check...")

    temp = element[start:start + 150]
    # print("temp: " + temp)
    tempStart = temp.find(">")
    # print(tempStart)

    tempEnd = temp.find("</")
    # print(tempEnd)

    # print("new value: " + temp[tempStart+1:tempEnd])
    return temp[tempStart + 1:tempEnd]


def process(list):
    print("hi")
    print("inside process...")
    for i in list:
        print(i['PlayerName'])
        print(i["Average"])


class statSpider(scrapy.Spider):
    name = 'hitSpider'

    file= open("statSpider/spiders/Website.txt", "r")



    start_urls = [file.read()]

    def parse(self, response):
        items = StatspiderItem()
        statMeets = response.css("tr.stat_meets_min").getall()
        statDoesntMeet = response.css('tr.stat_doesnt_meet_min').getall()

        for element in statMeets:
            items['statMeetMin'] = True

            ourPlayer = element.find('a class="hide-on-medium-down" data-player-id=')
            playerName = stringCheck(element, ourPlayer)
            items['playerName'] = playerName
            # print("Our player:" + playerName)

            avg = element.find('td data-label="AVG"')
            avgNumber = float(stringCheck(element, avg))
            items['avgNumber'] = avgNumber
            # print("Batting Average : " "%.3f" % avgNumber)  # make this go out 3 decimal places (currently 2)

            ops = element.find('td data-label="OPS"')
            opsNumber = float(stringCheck(element, ops))
            items['opsNumber'] = opsNumber
            # print("opsNumber: " "%.3f" % opsNumber)

            # stored as string- needs to be integer (split into two fields?)
            games = element.find('td data-label="GP-GS"')
            gamesNumber = stringCheck(element, games)
            items['gamesNumber'] = gamesNumber
            # print("GP-GS: " + gamesNumber)

            atBats = element.find('td data-label="AB"')
            atBatsNumber = stringCheck(element, atBats)
            items['atBatsNumber'] = int(atBatsNumber)
            # print("atBats: " + atBatsNumber)

            runs = element.find('td data-label="R"')
            runsNumber = stringCheck(element, runs)
            items['runsNumber'] = int(runsNumber)
            # print("runs number: " + runsNumber)
            # playerAttributes["Runs:"] = int(runsNumber)

            hits = element.find('td data-label="H"')
            hitsNumber = stringCheck(element, hits)
            items['hitsNumber'] = int(hitsNumber)
            # print("hits: " + hitsNumber)
            # playerAttributes["Hits:"] = int(hitsNumber)

            doubles = element.find('td data-label="2B"')
            doublesNumber = stringCheck(element, doubles)
            items['doublesNumber'] = int(doublesNumber)
            # print("Doubles: " + doublesNumber)
            # playerAttributes["Doubles:"] = int(doublesNumber)

            triples = element.find('td data-label="3B"')
            triplesNumber = stringCheck(element, triples)
            items['triplesNumber'] = int(triplesNumber)
            # print("Triples: " + triplesNumber)
            # playerAttributes["Triples: "] = int(triplesNumber)

            hr = element.find('td data-label="HR"')
            hrNumber = stringCheck(element, hr)
            items['hrNumber'] = int(hrNumber)
            # print("Home Run: " + hrNumber)
            # playerAttributes["Homeruns: "] = int(hrNumber)

            rbi = element.find('td data-label="RBI"')
            rbiNumber = stringCheck(element, rbi)
            items['rbiNumber'] = int(rbiNumber)
            # print("RBIs: " + rbiNumber)
            # playerAttributes["RBIs: "] = int(rbiNumber)

            tb = element.find('td data-label="TB"')
            tbNumber = stringCheck(element, tb)
            items['tbNumber'] = int(tbNumber)
            # print("Total Bases: " + tbNumber)
            # playerAttributes["Total Bases:"] = int(tbNumber)

            slg = element.find('td data-label="SLG%"')
            slgNumber = float(stringCheck(element, slg))
            items['slgNumber'] = float(slgNumber)
            # print("Slugging: " + slgNumber)
            # playerAttributes["Slugging %"] = float(slgNumber)

            bb = element.find('td data-label="BB"')
            bbNumber = stringCheck(element, bb)
            items['bbNumber'] = int(bbNumber)
            # print("walks: " + bbNumber)
            # playerAttributes["Walks: "] = int(bbNumber)

            hbp = element.find('td data-label="HBP"')
            hbpNumber = stringCheck(element, hbp)
            items['hbpNumber'] = int(hbpNumber)
            # print("HBPs: " + hbpNumber)
            # playerAttributes["HBP: "] = int(hbpNumber)

            strikeouts = element.find('td data-label="SO"')
            soNumber = stringCheck(element, strikeouts)
            items['soNumber'] = int(soNumber)
            # print("strikeouts: " + soNumber)
            # playerAttributes["Strikeouts: "] = int(soNumber)

            gdp = element.find('td data-label="GDP"')
            gdpNumber = stringCheck(element, gdp)
            items['gdpNumber'] = int(gdpNumber)
            # print("GDP: " + gdpNumber)
            # playerAttributes["GDP: "] = int(gdpNumber)

            obp = element.find('td data-label="OB%"')
            obpNumber = float(stringCheck(element, obp))
            items['obpNumber'] = float(obpNumber)
            # print("On-base percentage: " "%.3f" % obpNumber)
            # playerAttributes["OBP: "] = float(obpNumber)

            sf = element.find('td data-label="SF"')
            sfNumber = stringCheck(element, sf)
            items['sfNumber'] = int(sfNumber)
            # print("SF: " + sfNumber)
            # playerAttributes["SF: "] = int(sfNumber)

            sh = element.find('td data-label="SH"')
            shNumber = stringCheck(element, sh)
            items['shNumber'] = int(shNumber)
            # print("SH: " + shNumber)
            # playerAttributes["SH: "] = int(shNumber)

            sb = element.find('td data-label="SB"')
            sbmNumber = stringCheck(element, sb)
            print("this is sbmNumber" + str(sbmNumber))
            items['sbNumber'] = sbmNumber

            splitSBNumber = sbmNumber.split("-")
            print("This is splitNumber " + str(splitSBNumber))
            sbmNumber = int(splitSBNumber[0])
            sbaNumber = int(splitSBNumber[1])


            plateAppearances = (int(items['atBatsNumber']) + int(items['bbNumber']) + int(items['hbpNumber']) + int(items['sfNumber']))

            items['ISO'] = str(float(items['slgNumber']) - float(items['avgNumber']))
            items['BABIP']= str(float(float(items['hitsNumber']) - float(items['hrNumber'])) / (float(items['atBatsNumber']) - float(items['soNumber']) - float(items['hrNumber']) + float(items['sfNumber'])))


            tempExp = 0.89 * (int(items['hitsNumber']) - (int(items['doublesNumber']) + int(items['triplesNumber']) + int(items['hrNumber'])))
            tempNum= (0.69 * int(items['bbNumber'])) + (0.72 * int(items['hbpNumber'])) + tempExp + (1.27 * int(items['doublesNumber'])) + (1.62 * int(items['triplesNumber'])) + (2.1 * int(items['hrNumber']))
            tempDenom= int(items['atBatsNumber']) + int(items['bbNumber']) + int(items['sfNumber']) + int(items['hbpNumber'])

            items['wOBA'] = tempNum / tempDenom
            items['kPer'] = int(items['soNumber']) / plateAppearances
            items['bbPer'] = int(items['bbNumber']) / plateAppearances
            items['wRAA'] = (items['wOBA'] - 0.32 / 1.157) * plateAppearances
            items['runsCreated'] = (items['hitsNumber'] + items['bbNumber'] - (sbaNumber- sbmNumber)) * (items['tbNumber'] + (0.55 * sbmNumber)) / (items['atBatsNumber'] + items['bbNumber'])

            yield items

        for element in statDoesntMeet:
            print("inside doesntmeet loop")

            items['statMeetMin'] = False

            ourPlayer = element.find('a class="hide-on-medium-down" data-player-id=')
            playerName = stringCheck(element, ourPlayer)
            items['playerName'] = playerName
            # print("Our player:" + playerName)

            avg = element.find('td data-label="AVG"')
            avgNumber = float(stringCheck(element, avg))
            items['avgNumber'] = avgNumber
            # print("Batting Average : " "%.3f" % avgNumber)  # make this go out 3 decimal places (currently 2)

            ops = element.find('td data-label="OPS"')
            opsNumber = float(stringCheck(element, ops))
            items['opsNumber'] = opsNumber
            # print("opsNumber: " "%.3f" % opsNumber)

            # stored as string- needs to be integer (split into two fields?)
            games = element.find('td data-label="GP-GS"')
            gamesNumber = stringCheck(element, games)
            items['gamesNumber'] = gamesNumber
            # print("GP-GS: " + gamesNumber)

            atBats = element.find('td data-label="AB"')
            atBatsNumber = stringCheck(element, atBats)
            items['atBatsNumber'] = int(atBatsNumber)
            # print("atBats: " + atBatsNumber)

            runs = element.find('td data-label="R"')
            runsNumber = stringCheck(element, runs)
            items['runsNumber'] = int(runsNumber)
            # print("runs number: " + runsNumber)
            # playerAttributes["Runs:"] = int(runsNumber)

            hits = element.find('td data-label="H"')
            hitsNumber = stringCheck(element, hits)
            items['hitsNumber'] = int(hitsNumber)
            # print("hits: " + hitsNumber)
            # playerAttributes["Hits:"] = int(hitsNumber)

            doubles = element.find('td data-label="2B"')
            doublesNumber = stringCheck(element, doubles)
            items['doublesNumber'] = int(doublesNumber)
            # print("Doubles: " + doublesNumber)
            # playerAttributes["Doubles:"] = int(doublesNumber)

            triples = element.find('td data-label="3B"')
            triplesNumber = stringCheck(element, triples)
            items['triplesNumber'] = int(triplesNumber)
            # print("Triples: " + triplesNumber)
            # playerAttributes["Triples: "] = int(triplesNumber)

            hr = element.find('td data-label="HR"')
            hrNumber = stringCheck(element, hr)
            items['hrNumber'] = int(hrNumber)
            # print("Home Run: " + hrNumber)
            # playerAttributes["Homeruns: "] = int(hrNumber)

            rbi = element.find('td data-label="RBI"')
            rbiNumber = stringCheck(element, rbi)
            items['rbiNumber'] = int(rbiNumber)
            # print("RBIs: " + rbiNumber)
            # playerAttributes["RBIs: "] = int(rbiNumber)

            tb = element.find('td data-label="TB"')
            tbNumber = stringCheck(element, tb)
            items['tbNumber'] = int(tbNumber)
            # print("Total Bases: " + tbNumber)
            # playerAttributes["Total Bases:"] = int(tbNumber)

            slg = element.find('td data-label="SLG%"')
            slgNumber = float(stringCheck(element, slg))
            items['slgNumber'] = float(slgNumber)
            # print("Slugging: " + slgNumber)
            # playerAttributes["Slugging %"] = float(slgNumber)

            bb = element.find('td data-label="BB"')
            bbNumber = stringCheck(element, bb)
            items['bbNumber'] = int(bbNumber)
            # print("walks: " + bbNumber)
            # playerAttributes["Walks: "] = int(bbNumber)

            hbp = element.find('td data-label="HBP"')
            hbpNumber = stringCheck(element, hbp)
            items['hbpNumber'] = int(hbpNumber)
            # print("HBPs: " + hbpNumber)
            # playerAttributes["HBP: "] = int(hbpNumber)

            strikeouts = element.find('td data-label="SO"')
            soNumber = stringCheck(element, strikeouts)
            items['soNumber'] = int(soNumber)
            # print("strikeouts: " + soNumber)
            # playerAttributes["Strikeouts: "] = int(soNumber)

            gdp = element.find('td data-label="GDP"')
            gdpNumber = stringCheck(element, gdp)
            items['gdpNumber'] = int(gdpNumber)
            # print("GDP: " + gdpNumber)
            # playerAttributes["GDP: "] = int(gdpNumber)

            obp = element.find('td data-label="OB%"')
            obpNumber = float(stringCheck(element, obp))
            items['obpNumber'] = float(obpNumber)
            # print("On-base percentage: " "%.3f" % obpNumber)
            # playerAttributes["OBP: "] = float(obpNumber)

            sf = element.find('td data-label="SF"')
            sfNumber = stringCheck(element, sf)
            items['sfNumber'] = int(sfNumber)
            # print("SF: " + sfNumber)
            # playerAttributes["SF: "] = int(sfNumber)

            sh = element.find('td data-label="SH"')
            shNumber = stringCheck(element, sh)
            items['shNumber'] = int(shNumber)
            # print("SH: " + shNumber)
            # playerAttributes["SH: "] = int(shNumber)

            sb = element.find('td data-label="SB"')
            sbmNumber = stringCheck(element, sb)
            print("this is sbmNumber" + str(sbmNumber))
            items['sbNumber'] = sbmNumber

            splitSBNumber = sbmNumber.split("-")
            print("This is splitNumber " + str(splitSBNumber))
            sbmNumber = int(splitSBNumber[0])
            sbaNumber = int(splitSBNumber[1])





            plateAppearances = (int(items['atBatsNumber']) + int(items['bbNumber']) + int(items['hbpNumber']) + int(items['sfNumber']))

            items['ISO'] = str(float(items['slgNumber']) - float(items['avgNumber']))

            if (float(items['atBatsNumber']) - float(items['soNumber']) - float(items['hrNumber']) + float(items['sfNumber'])) == 0:
                items['BABIP'] = None

            else:
                items['BABIP'] = str(float(float(items['hitsNumber']) - float(items['hrNumber'])) / ( float(items['atBatsNumber']) - float(items['soNumber']) - float(items['hrNumber']) + float(items['sfNumber'])))

            tempExp = 0.89 * (int(items['hitsNumber']) - (int(items['doublesNumber']) + int(items['triplesNumber']) + int(items['hrNumber'])))
            tempNum = (0.69 * int(items['bbNumber'])) + (0.72 * int(items['hbpNumber'])) + tempExp + (1.27 * int(items['doublesNumber'])) + (1.62 * int(items['triplesNumber'])) + (2.1 * int(items['hrNumber']))
            tempDenom = int(items['atBatsNumber']) + int(items['bbNumber']) + int(items['sfNumber']) + int(items['hbpNumber'])

            items['wOBA'] = tempNum / tempDenom
            items['kPer'] = int(items['soNumber']) / plateAppearances
            items['bbPer'] = int(items['bbNumber']) / plateAppearances
            items['wRAA'] = (items['wOBA'] - 0.32 / 1.157) * plateAppearances
            items['runsCreated'] = (items['hitsNumber'] + items['bbNumber'] - sbaNumber) * (items['tbNumber'] + (0.55 * sbmNumber)) / items['atBatsNumber'] + items['bbNumber']

            yield items
        '''
        #---------------------------------------------------------------- these thing don't have stringCheck being used
            sbMade = element.find('td data-label="SB"')
            sbMadeNumber = int(element[sbMade + 39])
            print("stolen base made: " + str(sbMadeNumber))
            playerAttributes["Stolen Bases Made: "] = int(sbMadeNumber)

            sbAttempted = element.find('td data-label="SB"')
            sbAttemptedNumber = int(element[sbMade + 41])
            print("stolen base attempt: " + str(sbAttemptedNumber))
            playerAttributes["Stolen Bases Attempted: "] = int(sbAttemptedNumber)
        # ----------------------------------------------------------------
        '''


'''
#---------------------------------------------------------------- these thing don't have stringCheck being used
            sbMade = element.find('td data-label="SB"')
            sbMadeNumber = int(element[sbMade + 39])
            print("stolen base made: " + str(sbMadeNumber))
            playerAttributes["Stolen Bases Made: "] = int(sbMadeNumber)

            sbAttempted = element.find('td data-label="SB"')
            sbAttemptedNumber = int(element[sbMade + 41])
            print("stolen base attempt: " + str(sbAttemptedNumber))
            playerAttributes["Stolen Bases Attempted: "] = int(sbAttemptedNumber)
# ----------------------------------------------------------------
'''
