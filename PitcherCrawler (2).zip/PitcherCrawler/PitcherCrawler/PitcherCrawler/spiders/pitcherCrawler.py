from lib2to3.pgen2 import driver

import scrapy
from ..items import PitchercrawlerItem


def stringCheck(element, start):
    temp = element[start:start + 150]
    tempStart = temp.find(">")
    tempEnd = temp.find("</")

    return temp[tempStart + 1:tempEnd]

def commaCheck(element):
    comma = None
    for i in range(len(element)):
        if element[i] == ",":
            comma = i
            lastName = element[0:comma]
            firstName = element[comma + 2::]

    return firstName, lastName


class pitcherCrawler(scrapy.Spider):
    print("inside pitcherSpider")
    name = 'pitcherSpider'

    #file = open("PitcherCrawler/spiders/Website.txt", "r")

    start_urls = ["https://uncabulldogs.com/sports/baseball/stats/2021"]

    def parse(self, response):
        items = PitchercrawlerItem()
        getPitcher = response.css('[id="individual-overall-pitching"]').getall()

        element = getPitcher[0]

        numOfPlayers = element.count('a class="hide-on-medium-down" data-player-id=')


        for i in range(0, numOfPlayers):
            ourPlayer = element.find('a class="hide-on-medium-down" data-player-id=')
            playerName = stringCheck(element, ourPlayer)
            playerName = commaCheck(playerName)
            items['playerName'] = str(playerName[0] + " "+ (playerName[1]))

            era = element.find('td data-label="ERA"')
            eraNumber = float(stringCheck(element, era))
            items['eraNumber'] = eraNumber

            whip = element.find('td data-label="WHIP"')
            whipNumber = float(stringCheck(element, whip))
            items['whipNumber'] = whipNumber

            wl = element.find('td data-label="W-L"')
            wlNumber = stringCheck(element, wl)
            items['wlNumber'] = wlNumber

            games = element.find('td data-label="APP-GS"')
            gamesNumber = stringCheck(element, games)
            items['gamesNumber'] = gamesNumber

            sho = element.find('td data-label="SHO"')
            shoNumber = stringCheck(element, sho)
            items['shoNumber'] = shoNumber

            cg = element.find('td data-label="CG"')
            cgNumber = int(stringCheck(element, cg))
            items['cgNumber'] = int(cgNumber)

            sv = element.find('td data-label="SV"')
            svNumber = str(stringCheck(element, sv))
            items['svNumber'] = int(svNumber)
            # print("Doubles: " + doublesNumber)
            # playerAttributes["Doubles:"] = int(doublesNumber)

            ip = element.find('td data-label="IP"')
            ipNumber = float(stringCheck(element, ip))
            items['ipNumber'] = ipNumber
            # print("Triples: " + triplesNumber)
            # playerAttributes["Triples: "] = int(triplesNumber)

            h = element.find('td data-label="H"')
            hNumber = stringCheck(element, h)
            items['hNumber'] = int(hNumber)
            # print("Home Run: " + hrNumber)
            # playerAttributes["Homeruns: "] = int(hrNumber)

            r = element.find('td data-label="R"')
            rNumber = stringCheck(element, r)
            items['rNumber'] = int(rNumber)
            # print("RBIs: " + rbiNumber)
            # playerAttributes["RBIs: "] = int(rbiNumber)

            er = element.find('td data-label="ER"')
            erNumber = stringCheck(element, er)
            items['erNumber'] = int(erNumber)
            # print("Total Bases: " + tbNumber)
            # playerAttributes["Total Bases:"] = int(tbNumber)

            bb = element.find('td data-label="BB"')
            bbNumber = stringCheck(element, bb)
            items['bbNumber'] = int(bbNumber)
            # print("Slugging: " + slgNumber)
            # playerAttributes["Slugging %"] = float(slgNumber)

            so = element.find('td data-label="SO"')
            soNumber = stringCheck(element, so)
            items['soNumber'] = int(soNumber)
            # print("walks: " + bbNumber)
            # playerAttributes["Walks: "] = int(bbNumber)

            doubles = element.find('td data-label="2B"')
            doublesNumber = stringCheck(element, doubles)
            items['doublesNumber'] = int(doublesNumber)
            # print("HBPs: " + hbpNumber)
            # playerAttributes["HBP: "] = int(hbpNumber)

            triples = element.find('td data-label="3B"')
            triplesNumber = stringCheck(element, triples)
            items['triplesNumber'] = int(triplesNumber)
            # print("GDP: " + gdpNumber)
            # playerAttributes["GDP: "] = int(gdpNumber)

            hr = element.find('td data-label="HR"')
            hrNumber = (stringCheck(element, hr))
            items['hrNumber'] = int(hrNumber)
            # print("On-base percentage: " "%.3f" % obpNumber)
            # playerAttributes["OBP: "] = float(obpNumber)

            ab = element.find('td data-label="AB"')
            abNumber = int(stringCheck(element, ab))
            items['abNumber'] = abNumber
            # print("SF: " + sfNumber)
            # playerAttributes["SF: "] = int(sfNumber)

            bavg = element.find('td data-label="B/AVG"')
            bavgNumber = float(stringCheck(element, bavg))
            items['bavgNumber'] = bavgNumber

            wp = element.find('td data-label="WP"')
            wpNumber = stringCheck(element, wp)
            items['wpNumber'] = wpNumber

            hbp = element.find('td data-label="HBP"')
            hbpNumber = int(stringCheck(element, hbp))
            items['hbpNumber'] = hbpNumber

            bk = element.find('td data-label="BK"')
            bkNumber = stringCheck(element, bk)
            items['bkNumber'] = bkNumber

            sfa = element.find('td data-label="SFA"')
            sfaNumber = int(stringCheck(element, sfa))
            items['sfaNumber'] = sfaNumber

            sha = element.find('td data-label="SHA"')
            shaNumber = int(stringCheck(element, sha))
            items['shaNumber'] = shaNumber


#Calculations- ask tommy to help with calculation
            fip = 3.2 + ((13 * items['hrNumber'] + 3 * (items['hbpNumber'] + items['bbNumber']) - 2 * items['soNumber']) / items['ipNumber'])
            items['fipNumber'] = fip

            kPer = items['soNumber'] / items['abNumber'] * 100
            items['kPercentageNumber'] = kPer
            bbPer= items['bbNumber'] / items['abNumber'] * 100
            items['bbPercentageNumber'] = bbPer

            kPer9 = items['soNumber'] * 9 / items['ipNumber']
            items['kPer9Number'] = kPer9
            bbPer9 = items['bbNumber'] * 9 / items['ipNumber']
            items['bbPer9Number'] = bbPer9

            hrPer9 = items['hrNumber'] * 9 / items['ipNumber']
            items['hrPer9Number'] = hrPer9

            babip = (items['hNumber']- items['hrNumber'])/ (items['abNumber'] - items['soNumber'] - items['hrNumber'] + items['sfaNumber'])
            items['babipNumber'] = babip


            yield items

            element = element[sha + 200:]


