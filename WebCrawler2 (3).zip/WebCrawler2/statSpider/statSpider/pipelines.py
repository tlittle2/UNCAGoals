 # Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface


from itemadapter import ItemAdapter

import mysql.connector


class StatspiderPipeline:

    def __init__(self):
        self.create_connection()
        self.create_table()

    def create_connection(self):
        self.conn= mysql.connector.connect(host= 'localhost',user='root', password= 'root', database='tlittle2')
        self.curr= self.conn.cursor()



    def create_table(self):
        print("inside create table...")
        self.curr.execute("""DELETE FROM positionplayers_spring2021""")
        '''
        self.curr.execute("""CREATE TABLE positionplayers_spring2021(
                            playerName varchar(100),
                            Average FLOAT,
                            OPS FLOAT,
                            GP varchar(7),
                            AB INT(11),
                            R INT(11),
                            H INT(11),
                            2B INT(11),
                            3B INT(11),
                            HR INT(11),
                            RBI INT(11),
                            TB INT(11),
                            SLG FLOAT,
                            BB INT(11),
                            HBP INT(11),
                            SO INT(11),
                            GDP INT(11),
                            OBP FLOAT,
                            SF INT(11),
                            SH INT(11),
                            SB varchar(7),
                            ISO FLOAT,
                            BABIP FLOAT,
                            wOBA FLOAT,
                            Kpercentage FLOAT,
                            BBpercentage FLOAT, 
                            wRAA FLOAT, 
                            RunsCreated FLOAT,
                            BaseRuns FLOAT,
                            MeetsMin varchar(1)      
                            )""")
'''

    def storeItem(self, item):
        self.curr.execute("""INSERT INTO positionplayers_spring2021(playerName, Average, OPS, GP, AB, R, H, 2B, 3B, HR, 
        RBI, TB, SLG, BB, HBP, SO, GDP, OBP, SF, SH, SB, ISO, BABIP, wOBA, kPercentage, bbPercentage, wRAA, RunsCreated, BaseRuns, MeetsMin)
        VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s) """,(
               item['playerName'],
               str(item['avgNumber']),
               str(item['opsNumber']),
               item['gamesNumber'],
               item['atBatsNumber'],
               item['runsNumber'],
               item['hitsNumber'],
               item['doublesNumber'],
               item['triplesNumber'],
               item['hrNumber'],
               item['rbiNumber'],
               item['tbNumber'],
               str(item['slgNumber']),
               item['bbNumber'],
               item['hbpNumber'],
               item['soNumber'],
               item['gdpNumber'],
               str(item['obpNumber']),
               item['sfNumber'],
               item['shNumber'],
               item['sbNumber'],
               item['ISO'],
               item['BABIP'],
               item['wOBA'],
               item['kPer'],
               item['bbPer'],
               item['wRAA'],
               item['runsCreated'],
               item['baseRuns'],
               item['statMeetMin']
        ))
        self.conn.commit()





    def process_item(self, item, spider):
        self.storeItem(item)
        return item






