# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class StatspiderItem(scrapy.Item):
    playerName = scrapy.Field()
    avgNumber = scrapy.Field()
    opsNumber = scrapy.Field()
    gamesNumber = scrapy.Field()
    atBatsNumber = scrapy.Field()
    runsNumber = scrapy.Field()
    hitsNumber = scrapy.Field()
    doublesNumber = scrapy.Field()
    triplesNumber = scrapy.Field()
    hrNumber = scrapy.Field()
    rbiNumber = scrapy.Field()
    tbNumber = scrapy.Field()
    slgNumber = scrapy.Field()
    bbNumber = scrapy.Field()
    hbpNumber = scrapy.Field()
    soNumber = scrapy.Field()
    gdpNumber = scrapy.Field()
    obpNumber = scrapy.Field()
    sfNumber = scrapy.Field()
    shNumber = scrapy.Field()
    sbNumber = scrapy.Field()
    ISO = scrapy.Field()
    BABIP = scrapy.Field()
    wOBA = scrapy.Field()
    kPer = scrapy.Field()
    bbPer = scrapy.Field()
    wRAA = scrapy.Field()
    runsCreated = scrapy.Field()
    baseRuns= scrapy.Field()

    statMeetMin = scrapy.Field()
